//ToolTop
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});



//Popover
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});


//Smooth Scroll
$(function() {
 $('html').smoothScroll(1000);
});


//Back to Top
$("#scroll-to-top").illBeBack();


//wow.js
new WOW().init();

